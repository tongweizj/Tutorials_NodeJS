# openai-server

#### chatGTP接口开发（采用express+ts开发opeanai接口，仅后端代码，前端代码请前往openai-public）  
##### 示例：https://kiritosa.com/ai
