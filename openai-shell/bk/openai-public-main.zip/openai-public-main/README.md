# openai-public
项目示例：https://kiritosa.com/ai/    
搭配openai3.5接口写出的聊天AI页，后端项目请前往[openai-server](https://github.com/KiritoCheng/openai-server)仓库查看。

![image](https://user-images.githubusercontent.com/19926113/231107329-c43a1592-aef5-412d-a42b-2c49342b8921.png)
